# FDPClient 
[![State-of-the-art Shitcode](https://img.shields.io/static/v1?label=State-of-the-art&message=Shitcode&color=7B5804)](https://github.com/trekhleb/state-of-the-art-shitcode)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/SkidderMC/FDPClient)
![GitHub lines of code](https://tokei.rs/b1/github/SkidderMC/FDPClient)
![Minecraft](https://img.shields.io/badge/game-Minecraft-brightgreen)  
A free mixin-based injection hacked-client for Minecraft using Minecraft Forge based on LiquidBounce.

Website: [fdpinfo.github.io](https://fdpinfo.github.io)  
Latest [github-actions](https://github.com/SkidderMC/FDPClient/actions/workflows/build.yml?query=event%3Apush)  
Discord: [dsc.gg/fdpdiscord](https://dsc.gg/fdpdiscord)

## FDP TEAM

### Liulihaocai
OWNER | https://github.com/hax0r31337

### Zywl
OWNER | https://github.com/opZywl

### Co丶Dynamic 
DEV | https://github.com/contionability

### gatodepan
CONTRIBUTOR | https://github.com/gatooooooo

### DinoFeng
CONTRIBUTOR | https://github.com/DinoFengz

### Dg636
CONTRIBUTOR | https://github.com/C00LC0D35

### XiGuaHanHan
CONTRIBUTOR | https://github.com/Wlenk

(please do not ask us to be added here)
