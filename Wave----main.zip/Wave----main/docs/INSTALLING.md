# FDPClient 
[![State-of-the-art Shitcode](https://img.shields.io/static/v1?label=State-of-the-art&message=Shitcode&color=7B5804)](https://github.com/trekhleb/state-of-the-art-shitcode)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/SkidderMC/FDPClient)
![GitHub lines of code](https://tokei.rs/b1/github/SkidderMC/FDPClient)
![Minecraft](https://img.shields.io/badge/game-Minecraft-brightgreen)  
A free mixin-based injection hacked-client for Minecraft using Minecraft Forge based on LiquidBounce.

Website: [fdpinfo.github.io](https://fdpinfo.github.io)  
Latest [github-actions](https://github.com/SkidderMC/FDPClient/actions/workflows/build.yml?query=event%3Apush)  
Discord: [dsc.gg/fdpdiscord](https://dsc.gg/fdpdiscord)

## How To Install FDP?
- **Step 1:** Install Java 8 [here](https://www.java.com/en/download/) (Skip if you have Java 8)
- **Step 2:** Install Forge 1.8.9 [here](https://maven.minecraftforge.net/net/minecraftforge/forge/1.8.9-11.15.1.2318-1.8.9/forge-1.8.9-11.15.1.2318-1.8.9-installer.jar) (Skip if you have Forge)
- **Step 3:** Start Forge and then close it
- **Step 4:** Put the FDPClient jar in the mods folder in your Minecraft directory (① %appdata%\\.minecraft\mods or if you are using the official launcher, click the installations tab then click the folder icon next to forge.)
- **Step 5:** Voilà! You have sucessfully installed FDPClient!

