package net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.vanilla

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.modules.combat.velocitys.vulcan.VelocityMode
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.S12PacketEntityVelocity

class IntaveVelocity : VelocityMode("Intave") {

    private val modeValue = ListValue("${valuePrefix}Mode", arrayOf("Motion", "Jump", "Smart", "Simple", "Intave3fmc", "3fmc"), "Motion")
    private val jumpReductionValue = BoolValue("${valuePrefix}ExtraReduction", false)
    private val jumpReductionAmountValue = FloatValue("${valuePrefix}ExtraReductionAmount", 0.6f, 0f, 1f)
    private val motionValue = FloatValue("${valuePrefix}Motion", 0.42f, 0f, 1f)
    private val failValue = BoolValue("${valuePrefix}SmartFail", true)
    private val failRateValue = FloatValue("${valuePrefix}FailRate", 0.3f, 0f, 1f)
    private val failJumpValue = FloatValue("${valuePrefix}FailJumpRate", 0.25f, 0f, 1f)
    private val intaveMultiplierValue = FloatValue("${valuePrefix}IntaveMultiplier", 0.3f, 0f, 1f)

    private var doJump = true
    private var failJump = false

    override fun onVelocity(event: UpdateEvent) {
        when (modeValue.get().lowercase()) {
            "intave3fmc" -> {
                if (mc.thePlayer != null && mc.thePlayer.onGround) {
                    val multiplier = intaveMultiplierValue.get().toDouble()
                    mc.thePlayer.motionX *= multiplier
                    mc.thePlayer.motionZ *= multiplier
                    mc.thePlayer.motionY = 0.0
                }
            }

            "3fmc" -> {
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.jump()
                    mc.thePlayer.motionY *= 0.9
                    mc.thePlayer.motionX *= 0.55
                    mc.thePlayer.motionZ *= 0.8
                }
            }

            else -> {
                if ((failJump || mc.thePlayer.hurtTime > 3) && mc.thePlayer.onGround) {
                    if (failJump) failJump = false

                    if (failValue.get() && Math.random() <= failRateValue.get().toDouble()) {
                        if (Math.random() <= failJumpValue.get().toDouble()) {
                            doJump = true
                            failJump = true
                        } else {
                            doJump = false
                        }
                    } else {
                        doJump = true
                    }
                } else {
                    doJump = true
                }
            }
        }
    }

    override fun onVelocityPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is S12PacketEntityVelocity && jumpReductionValue.get()) {
            packet.motionX = (packet.motionX * jumpReductionAmountValue.get().toDouble()).toInt()
            packet.motionZ = (packet.motionZ * jumpReductionAmountValue.get().toDouble()).toInt()
        }

        if (modeValue.get().equals("3fmc", ignoreCase = true)) {
            packet as S12PacketEntityVelocity
            packet.motionY = (packet.motionY * 0.85).toInt()
        }
    }
}
