package net.ccbluex.liquidbounce.event;

public enum EventType {
    PRE,
    POST
}
